</body>
</html>

<?php
echo "Copyright &copy; 2023 IBay Inc."
?>